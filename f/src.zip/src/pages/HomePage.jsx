import React from "react";
import { useState, useEffect, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import {Link, User, MessageSquare} from 'lucide-react'
import ForumService from "../services/ForumService";
import Chat from "../components/chat/Chat";

const HomePage = () => {
  const [topics, setTopics] = useState([]);
  const [loading, setLoading] = useState(true);
  const { currentUser } = React.useContext(AuthContext);
  
  useEffect(() => {
    const fetchTopics = async () => {
      try {
        const data = await ForumService.getTopics();
        setTopics(data);
      } catch (error) {
        console.error('Ошибка загрузки тем:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchTopics();
  }, []);
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold">Темы форума</h1>
        {currentUser?.isAdmin && (
          <Link to="/create-topic" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            Создать тему
          </Link>
        )}
      </div>
      
      {loading ? (
        <div className="text-center py-8">Загрузка...</div>
      ) : topics.length > 0 ? (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          {topics.map((topic) => (
            <div key={topic.id} className="border-b last:border-b-0">
              <Link 
                to={`/topics/${topic.id}`}
                className="block p-4 hover:bg-gray-50"
              >
                <div className="flex justify-between">
                  <h2 className="text-lg font-semibold text-blue-800">{topic.title}</h2>
                  <div className="text-gray-500 text-sm">
                    {new Date(topic.createdAt).toLocaleDateString()}
                  </div>
                </div>
                <p className="text-gray-600 mt-1 line-clamp-2">{topic.content}</p>
                <div className="flex items-center mt-2 text-sm text-gray-500">
                  <span className="flex items-center">
                    <User className="w-4 h-4 mr-1" />
                    {topic.author}
                  </span>
                  <span className="flex items-center ml-4">
                    <MessageSquare className="w-4 h-4 mr-1" />
                    {topic.repliesCount} ответов
                  </span>
                </div>
              </Link>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8 text-gray-500">
          Нет доступных тем. {currentUser?.isAdmin ? 'Создайте первую тему!' : 'Темы появятся позже.'}
        </div>
      )}
      
      {/* Блок чата */}
      <div className="mt-12">
        <h2 className="text-xl font-bold mb-4">Общий чат</h2>
        <Chat />
      </div>
    </div>
  );
};

export default HomePage;