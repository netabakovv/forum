import { API_URL } from './api.js';
import AuthService from './AuthService.js';

const ForumService = {
  getTopics: async () => {
    try {
      const response = await fetch(`${API_URL}/forum/topics`);
      if (!response.ok) throw new Error('Ошибка получения тем');
      return await response.json();
    } catch (error) {
      console.error('Ошибка получения тем:', error);
      throw error;
    }
  },

  getTopic: async (id) => {
    try {
      const response = await fetch(`${API_URL}/forum/topics/${id}`);
      if (!response.ok) throw new Error('Ошибка получения темы');
      return await response.json();
    } catch (error) {
      console.error('Ошибка получения темы:', error);
      throw error;
    }
  },

  createTopic: async (title, content) => {
    try {
      const response = await AuthService.authFetch(`${API_URL}/forum/topics`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, content }),
      });
      return await response.json();
    } catch (error) {
      console.error('Ошибка создания темы:', error);
      throw error;
    }
  },

  createReply: async (topicId, content) => {
    try {
      const response = await AuthService.authFetch(`${API_URL}/forum/topics/${topicId}/replies`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content }),
      });
      return await response.json();
    } catch (error) {
      console.error('Ошибка создания ответа:', error);
      throw error;
    }
  },

  deleteTopic: async (id) => {
    try {
      await AuthService.authFetch(`${API_URL}/forum/topics/${id}`, {
        method: 'DELETE',
      });
      return true;
    } catch (error) {
      console.error('Ошибка удаления темы:', error);
      throw error;
    }
  },

  deleteReply: async (topicId, replyId) => {
    try {
      await AuthService.authFetch(`${API_URL}/forum/topics/${topicId}/replies/${replyId}`, {
        method: 'DELETE',
      });
      return true;
    } catch (error) {
      console.error('Ошибка удаления ответа:', error);
      throw error;
    }
  }
};

export default ForumService;